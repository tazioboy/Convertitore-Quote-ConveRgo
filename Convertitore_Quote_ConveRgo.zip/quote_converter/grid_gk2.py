"""Lettore dei grigliati IGM GK2/G R2 (fogli 50K).

Il file GK2 contiene, tra gli altri, il blocco GEOIDE (ITALGEO2005) e le
trasformazioni planimetriche ETRF89<->ROMA40, ED50<->ROMA40 e
ETRF89<->ETRF2000.

Per il blocco GEOIDE i valori sono memorizzati dal NORD-EST: la prima riga e'
il bordo nord e la prima colonna il bordo est. Per usare coordinate geografiche
con origine SUD-OVEST, la matrice viene quindi ribaltata su entrambe le direzioni.
L'interpolazione e' bilineare, come richiesto per l'uso del grigliato.
"""
import os
import re
import numpy as np

GEOID_ROWS = 10
GEOID_COLS = 14
GEOID_STEP_LAT = 2.0 / 60.0
GEOID_STEP_LON = 2.0 / 60.0
SHIFT_ROWS = 6
SHIFT_COLS = 6
SHIFT_STEP_LAT = 5.0 / 60.0
SHIFT_STEP_LON = 7.5 / 60.0


class GK2ParseError(ValueError):
    pass


def parse_gk2(path):
    """Parsa un GK2 in blocchi, preservando l'ordine dei valori numerici."""
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        txt = fh.read()
    toks = re.findall(r'"[^"]*"|[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?', txt)
    blocks = []
    cur = None
    for tok in toks:
        if tok.startswith('"'):
            hdr = tok[1:-1]
            # Ogni nuovo token testuale apre un nuovo blocco se il precedente
            # aveva gia' ricevuto numeri; i primi due token sono parte dell'header.
            if cur is None:
                cur = {"hdr": [], "nums": []}
                blocks.append(cur)
            elif cur["nums"]:
                cur = {"hdr": [], "nums": []}
                blocks.append(cur)
            cur["hdr"].append(hdr)
        elif cur is not None:
            cur["nums"].append(float(tok))
    return blocks


def _block(blocks, name):
    for b in blocks:
        if name in b["hdr"]:
            return b
    return None


class ShiftGrid:
    def __init__(self, arrays, lat0, lon0):
        if len(arrays) != len([a for a in arrays]):
            raise GK2ParseError("Numero di componenti griglia non valido")
        self.arrs = [np.asarray(a, dtype="float64").reshape(SHIFT_ROWS, SHIFT_COLS)
                     for a in arrays]
        self.lat0 = float(lat0)
        self.lon0 = float(lon0)
        self.lat_max = self.lat0 + (SHIFT_ROWS - 1) * SHIFT_STEP_LAT
        self.lon_max = self.lon0 + (SHIFT_COLS - 1) * SHIFT_STEP_LON

    def contains(self, lat, lon):
        return (self.lat0 <= lat <= self.lat_max and
                self.lon0 <= lon <= self.lon_max)

    def margin(self, lat, lon):
        return min((lat - self.lat0) / SHIFT_STEP_LAT,
                   (self.lat_max - lat) / SHIFT_STEP_LAT,
                   (lon - self.lon0) / SHIFT_STEP_LON,
                   (self.lon_max - lon) / SHIFT_STEP_LON)

    def values(self, lat, lon):
        r = (lat - self.lat0) / SHIFT_STEP_LAT
        c = (lon - self.lon0) / SHIFT_STEP_LON
        r0 = min(max(int(np.floor(r)), 0), SHIFT_ROWS - 2)
        c0 = min(max(int(np.floor(c)), 0), SHIFT_COLS - 2)
        fr, fc = r - r0, c - c0
        out = []
        for a in self.arrs:
            out.append(float(
                a[r0, c0] * (1-fc) * (1-fr) +
                a[r0, c0+1] * fc * (1-fr) +
                a[r0+1, c0] * (1-fc) * fr +
                a[r0+1, c0+1] * fc * fr))
        return tuple(out)


class GK2Sheet:
    def __init__(self, path):
        self.path = path
        blocks = parse_gk2(path)
        geo = _block(blocks, "GEOIDE")
        if geo is None:
            raise GK2ParseError("Blocco GEOIDE non trovato")

        # -------------------------- griglie planimetriche
        self.shift_ed50 = self.shift_e89r40 = self.shift_e2k = None
        n = _block(blocks, "ETRF89-ROMA40")
        if n is not None and len(n["nums"]) >= 74:
            vals = n["nums"]
            lat0, lon0 = vals[72], vals[73]
            self.shift_e89r40 = ShiftGrid([vals[:36], vals[36:72]], lat0, lon0)
            e = _block(blocks, "ED50-ROMA40")
            if e is not None and len(e["nums"]) >= 72:
                ev = e["nums"]
                # Il blocco ED50-ROMA40 usa la stessa origine della griglia
                # ETRF89-ROMA40, come specificato dal formato GK2.
                self.shift_ed50 = ShiftGrid([ev[:36], ev[36:72]], lat0, lon0)

        n = _block(blocks, "ETRF89-ETRF2000")
        if n is not None and len(n["nums"]) >= 110:
            vals = n["nums"]
            self.shift_e2k = ShiftGrid([vals[:36], vals[36:72], vals[72:108]],
                                       vals[108], vals[109])

        # -------------------------- GEOIDE / ITALGEO2005
        vals = geo["nums"]
        expected = GEOID_ROWS * GEOID_COLS + 4
        if len(vals) < expected:
            raise GK2ParseError(
                "Blocco GEOIDE incompleto: %d numeri, attesi almeno %d" %
                (len(vals), expected))

        ngrid = GEOID_ROWS * GEOID_COLS
        # I 4 valori finali sono origine SW (lat, lon) e due valori di servizio.
        self.lat0 = float(vals[ngrid])
        self.lon0 = float(vals[ngrid + 1])
        raw = np.asarray(vals[:ngrid], dtype="float64").reshape(GEOID_ROWS, GEOID_COLS)

        # Nel blocco GEOIDE i valori sono ordinati da Nord a Sud per righe,
        # mentre le colonne crescono da Ovest a Est. Dopo il solo ribaltamento
        # delle righe arr[0,0] corrisponde al nodo Sud-Ovest.
        self.arr = raw[::-1, :]
        self.rows = GEOID_ROWS
        self.cols = GEOID_COLS
        self.step_lat = GEOID_STEP_LAT
        self.step_lon = GEOID_STEP_LON
        self.lat_max = self.lat0 + (self.rows - 1) * self.step_lat
        self.lon_max = self.lon0 + (self.cols - 1) * self.step_lon
        self.name = os.path.basename(path)

    def contains(self, lon, lat):
        eps = 1e-10
        return (self.lon0 - eps <= lon <= self.lon_max + eps and
                self.lat0 - eps <= lat <= self.lat_max + eps)

    def margin(self, lon, lat):
        return min(lon - self.lon0, self.lon_max - lon,
                   lat - self.lat0, self.lat_max - lat)

    def value(self, lon, lat):
        """Ondulazione N interpolata bilinearmente in metri."""
        if not self.contains(lon, lat):
            return None
        c = (lon - self.lon0) / self.step_lon
        r = (lat - self.lat0) / self.step_lat
        c0 = min(max(int(np.floor(c)), 0), self.cols - 2)
        r0 = min(max(int(np.floor(r)), 0), self.rows - 2)
        fc, fr = c - c0, r - r0
        a00 = self.arr[r0, c0]
        a10 = self.arr[r0, c0 + 1]
        a01 = self.arr[r0 + 1, c0]
        a11 = self.arr[r0 + 1, c0 + 1]
        return float(a00*(1-fc)*(1-fr) + a10*fc*(1-fr) +
                     a01*(1-fc)*fr + a11*fc*fr)


class GK2Folder:
    """Collezione di GK2. Il foglio viene scelto automaticamente in base al punto."""
    def __init__(self, folder):
        self.folder = folder
        self.sheets = []
        for nm in sorted(os.listdir(folder), key=str.lower):
            if os.path.splitext(nm)[1].lower() not in (".gk2", ".gr2"):
                continue
            try:
                self.sheets.append(GK2Sheet(os.path.join(folder, nm)))
            except Exception:
                # Un file non valido non deve impedire l'uso degli altri 161.
                continue
        if not self.sheets:
            raise GK2ParseError("Nessun file .GK2/.GR2 valido in %s" % folder)
        self._crs = None

    @property
    def crs(self):
        if self._crs is None:
            from qgis.core import QgsCoordinateReferenceSystem
            self._crs = QgsCoordinateReferenceSystem("EPSG:4258")
        return self._crs

    def _best(self, attr, lat, lon):
        candidates = []
        for sh in self.sheets:
            g = getattr(sh, attr)
            if g is not None and g.contains(lat, lon):
                candidates.append((g.margin(lat, lon), sh, g))
        if not candidates:
            return None
        candidates.sort(key=lambda t: t[0], reverse=True)
        return candidates[0][2]

    def shift_ed50_roma40(self, lat, lon):
        g = self._best("shift_ed50", lat, lon)
        return g.values(lat, lon) if g else None

    def shift_etrf89_roma40(self, lat, lon):
        g = self._best("shift_e89r40", lat, lon)
        return g.values(lat, lon) if g else None

    def shift_etrf2000_etrf89(self, lat, lon):
        g = self._best("shift_e2k", lat, lon)
        return g.values(lat, lon) if g else None

    def value(self, lon, lat, return_sheet=False):
        candidates = [s for s in self.sheets if s.contains(lon, lat)]
        if not candidates:
            return (None, None) if return_sheet else None
        # In caso di sovrapposizione scegli il foglio nel cui interno il punto
        # e' piu' lontano dai bordi. Per i GK2 sovrapposti i valori coincidono
        # entro la precisione del grigliato.
        sh = max(candidates, key=lambda s: s.margin(lon, lat))
        n = sh.value(lon, lat)
        return (n, sh.name) if return_sheet else n
